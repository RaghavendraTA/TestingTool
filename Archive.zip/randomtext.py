from numpy import random

letters = list(map(chr, range(65, 91)))
letters += list(map(chr, range(97, 123)))

for count in range(1, 100000 + 1):
    random.shuffle(letters)
    n = random.randint(5, 25)
    start = random.randint(0, 26-n)
    temp = ''.join(letters[start: start + n])
    print(temp, end=' ')
    if count % 10 == 0: print()
