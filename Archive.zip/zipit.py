import gzip

with open('out.txt', 'r') as fp:
    compressed_data = gzip.compress(bytes(fp.read(), 'UTF-8'))
    encond_fp = open('enconde.txt.gzip', 'wb').write(compressed_data)

