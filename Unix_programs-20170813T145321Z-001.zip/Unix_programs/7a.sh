clear
h=`who|head -1|tr -s " "|cut -d " " -f5|cut -d ":" -f1`
if [ $h -lt 12 ]
then
	echo "Good Morning"
elif [ $h -gt 12 -a $h -lt 16 ]
then
	eho "Good Morning"
else
	echo "Good Morning"
fi
