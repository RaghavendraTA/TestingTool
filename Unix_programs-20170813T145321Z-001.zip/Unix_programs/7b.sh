clear
if [ $# -lt 2 ]
then
	echo "Invalid arguements"
	exit
fi
for word in `cat $1`
do
	for file in $*
	do
		if [ $file != "$1" ]
		then
			echo "Count : $Word in $file"
			echo `grep -iow "$word" $file|wc -w`
		fi
	done
done
