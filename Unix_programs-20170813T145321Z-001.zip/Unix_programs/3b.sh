clear
trap " " 1 2 3
stty -echo
echo "Enter the Password"
read key1
echo "Re-Enter the password"
read key2
if [ "$key1" = "$key2" ]
then
	until [ "$key3" = "$key1" ]
	do
		echo "Enter the correct password to unlock:"
		read key3
	done
else
	echo "Password Matched"
fi
stty echo
