clear
if [ $# -eq  0 -o $# -gt 1 ]
then
	echo "Invalid Files"
	exit
else if [ -d mydir ]
then
	cd mydir
	rm *
	cd ..
	rmdir mydir
fi
mkdir ~/mydir
find . -name $1>findfiles 2>err.lst
if [ -s findfiles ]
then
	echo "Search successfull"
else
	echo "Search Unseccessfull"
fi
if [ -s err.lst ]
then
	echo "Give the correct pattern"
	exit
fi
for i in `cat findfiles`
do
	echo "Contents"
	cat $i
	cp $i ~/mydir/
done
fi
