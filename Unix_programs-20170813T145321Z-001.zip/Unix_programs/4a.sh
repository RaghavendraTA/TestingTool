if [ $# -eq 0 ]
then
	echo "Invalid arguments"
	exit
else
	for fn in "$@"
	do
		if [ -f $fn ]
		then
			echo $fn|tr '[a-z]' '[A-Z]'
		else
			echo "File not found"
		fi
	done
fi
