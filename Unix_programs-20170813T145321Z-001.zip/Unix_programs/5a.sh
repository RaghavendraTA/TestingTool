clear
if [ $# -ne 1 ]
then
	echo "Invalid Arguments"
	exit
else
	if [ -e $1 ]
	then
		echo "File $1 creation time"
		echo `ls -l $1|tr -s " "|cut -d " " -f6,7,8`
	else
		echo "File not found"
	fi
fi
