clear
echo "Enter user Name"
read usr
h=`who|grep $usr|tr -s " "|head -1|cut -d " " -f5`
uhr=`echo $h|cut -d ":" -f1`
umin=`echo $h|cut -d ":" -f2`
shr=`date "+%H"`
smin=`date "+%M"`
h=`expr $shr - $uhr`
m=`expr $smin - $umin`
echo "User Name : $usr"
echo "Login-period = $h : $m"
