echo "Enter the User Name :\c"
read usr
umin=`who|grep $usr|tr -s " "|head -1|cut -d " " -f4|cut -d ":" -f2`
smin=`date "+%M"`
m=`expr $smin - $umin`
if [ $m -lt 1 ]
then
	echo "User Name : $usr has logged in"
else
	echo "$usr has not logged in specified time : $m"
fi
