clear
a=`date +%e`
if [ $a -lt 10 ]
then
	cal|sed "s/$a / * /"
else
	cal|sed "s/$a /** /"
fi
