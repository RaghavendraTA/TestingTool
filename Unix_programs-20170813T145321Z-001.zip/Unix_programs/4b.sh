clear
if [ "$2" != "" ]
then
	cwd=`pwd`
	cd $2
	l=`ls -lR $1|tr -s " "|cut -d " " -f2`
	cd $cwd
else
	l=`ls -l $1|tr -s " "|cut -d " " -f2`
fi
echo "Number of lines to the file $1 : $l"
