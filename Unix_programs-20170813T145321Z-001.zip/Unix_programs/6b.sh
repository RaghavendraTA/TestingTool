clear
ls>listfiles
echo "The List of files greater than 9\n"
for i in `cat listfiles`
do
	len=`expr length "$i"`
	if [ $len -gt 9 ]
	then
		echo $i
	fi
done
