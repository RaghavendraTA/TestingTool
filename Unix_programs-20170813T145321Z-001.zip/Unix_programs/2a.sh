clear
if [ $# -ne 2 ]
then
	echo "Invalid number of argments"
else
	ls -l $1|cut -d " " -f1>file1
	ls -l $2|cut -d " " -f1>file2
	if cmp file1 file2
	then
		echo "\n\nBoth File have same permissions\n"
		cat file1
	else
		echo "\n\nFile have permission"
		echo "Permission of the $1:"
		cat file1
		echo "permission of the $2:"
		cat file2
	fi
fi
