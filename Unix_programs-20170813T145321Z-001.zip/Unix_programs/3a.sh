clear
echo "Enter a filename"
read file
if [ -f $file ]
then
	echo "The File Permission are : `ls -l $file|cut -d ' ' -f1`"
	echo "The File Links are : `ls -l $file|cut -d ' ' -f3`"
	echo "The File Username is : `ls -l $file|cut -d ' ' -f4`"
	echo "The File Group name is : `ls -l $file|cut -d ' ' -f6`"
	echo "The File Size is : `ls -l $file|cut -d ' ' -f8`"
	echo "The File Modified date and time : `ls -l $file|cut -d ' ' -f9,10,11`"
	echo "The File Name is : `ls -l $file|cut -d ' ' -f12`"
else
	echo "The file doesn't exist"
fi
