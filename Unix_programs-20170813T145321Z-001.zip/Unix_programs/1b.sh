if [ $# -ne 1 ]
then
	echo "Invalid Arguments"
else
	t=`echo $1|cut -d "/" -f1`
	if [ -d $t ]
	then
		echo "The folder already exist"
	else
		mkdir -p $1
	fi
fi
