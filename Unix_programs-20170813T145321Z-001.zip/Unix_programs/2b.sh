clear
if [ $# -eq 0 ]
then
	echo "No command line argument passed"
	exit
fi
for i in "$@"
do
	ck=`cat /etc/passwd|cut -d ":" -f1|grep "^$i"`
	if [ "$ck" != "$i" ]
	then
		echo "Error:$i is on invalid login name"
	else
		echo "\nHome directory for $i is :"
		cat /etc/passwd|grep "$i"|cut -d ":" -f6
	fi
shift
done
