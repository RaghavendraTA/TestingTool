clear
if [ $# -ne 1 ]
then
	echo "Invalid arguments"
	exit
else
	if [ ! -d $1 ]
	then
		echo "Directory doesn't exist"
	else
		ms=`ls -lR $1|grep '^-'|tr -s " "|cut -d " " -f5,9|sort -n|tail -1`
		echo "The file name is : `echo $ms|cut -d ' ' -f2`"
		echo "The file size is : `echo $ms|cut -d ' ' -f1`bytes "
	fi
fi
